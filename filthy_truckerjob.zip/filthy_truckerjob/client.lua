local Framework = nil
local PlayerData = {}
local ActiveJob = nil
local JobGiverPed = nil
local TruckVehicle = nil
local TrailerVehicle = nil
local CarriedBox = nil
local Boxes = {}
local Enemies = {}
local BoxBlips = {}
local DeliveryBlip = nil
local ReturnBlip = nil
local PickupZone = nil

local function DebugPrint(message)
    if Config.Debug then
        lib.print.info('[FILTHY_TRUCKERJOB] ' .. tostring(message))
    end
end

local function GetFrameworkObject()
    local fw = Config.GetFramework()
    if fw == 'qbox' then
        Framework = exports.qbx_core
        PlayerData = exports.qbx_core:GetPlayerData()
        return exports.qbx_core
    else
        Framework = exports['qb-core']:GetCoreObject()
        PlayerData = Framework.Functions.GetPlayerData()
        return Framework
    end
end

local function ShowNotification(message, type, duration)
    if Config.GetFramework() == 'qbox' then
        exports.qbx_core:Notify(message, type or 'inform', duration or 5000)
    else
        Framework.Functions.Notify(message, type or 'primary', duration or 5000)
    end
end

local function IsJobWhitelisted()
    return true
end

function ShowMkizeMenu()
    if lib.progressCircle({
        duration = 1500,
        position = 'bottom',
        label = 'Talking to Mr. Mkize...',
        useWhileDead = false,
        canCancel = true,
        disable = {
            move = true,
            car = true,
            mouse = false,
            combat = true,
        },
        anim = {
            dict = 'oddjobs@assassinate@vice@hooker',
            clip = 'argue_a',
        },
    }) then
        CreateMkizeContextMenu()
    end
end

function CreateMkizeContextMenu()
    local cooldownInfo = lib.callback.await('filthy_truckerjob:server:getCooldownInfo', false)
    local activeJobCount = lib.callback.await('filthy_truckerjob:server:getActiveJobCount', false)
    
    local canStartJob = not ActiveJob and not cooldownInfo.onCooldown
    local cooldownText = ""
    local cooldownProgress = 0
    
    if cooldownInfo.onCooldown then
        local minutes = math.ceil(cooldownInfo.timeRemaining / 60)
        cooldownText = string.format("Cooldown: %d minutes remaining", minutes)
        cooldownProgress = math.max(0, 100 - ((cooldownInfo.timeRemaining / (Config.JobCooldown * 60)) * 100))
    end
    
    local menuOptions = {
        {
            title = 'Mr. Mkize - Trucking Operations',
            icon = 'fas fa-truck',
            description = 'Professional cargo delivery services',
            readOnly = true,
            metadata = {
                'Active Jobs: ' .. activeJobCount .. '/' .. Config.MaxActiveJobs,
                cooldownInfo.onCooldown and cooldownText or 'Ready for work'
            }
        }
    }
    
    if not ActiveJob then
        if cooldownInfo.onCooldown then
            table.insert(menuOptions, {
                title = 'Job Cooldown Active',
                icon = 'fas fa-clock',
                iconAnimation = 'spin',
                description = 'Wait before starting another job',
                disabled = true,
                colorScheme = 'red',
                progress = cooldownProgress,
                metadata = {
                    cooldownText
                }
            })
        else
            table.insert(menuOptions, {
                title = 'Start Illegal Job',
                icon = 'fas fa-mask',
                description = 'High risk, high reward cargo delivery',
                colorScheme = 'red',
                disabled = not canStartJob,
                onSelect = function()
                    StartJobConfirmation('illegal')
                end,
                metadata = {
                    'Payment: $' .. Config.Payment.min .. ' - $' .. Config.Payment.max,
                    'Risk Level: High',
                    'Police Alert: Yes'
                }
            })
            
            table.insert(menuOptions, {
                title = 'Start Legal Job',
                icon = 'fas fa-clipboard-check',
                description = 'Safe and legitimate delivery routes',
                colorScheme = 'green',
                disabled = not canStartJob,
                onSelect = function()
                    StartJobConfirmation('legal')
                end,
                metadata = {
                    'Payment: $' .. Config.LegalJobSettings.basePayment .. '+',
                    'Risk Level: Low',
                    'Multiple Routes: Yes'
                }
            })
        end
    else
        if ActiveJob.stage == 'return' then
            table.insert(menuOptions, {
                title = 'Return Truck',
                icon = 'fas fa-truck-ramp-box',
                description = 'Complete your job and receive payment',
                colorScheme = 'green',
                onSelect = function()
                    ReturnTruckConfirmation()
                end,
                metadata = {
                    'Job Type: ' .. string.upper(ActiveJob.type or 'ILLEGAL'),
                    'Ready for completion'
                }
            })
        else
            table.insert(menuOptions, {
                title = 'Job in Progress',
                icon = 'fas fa-hourglass-half',
                iconAnimation = 'spin',
                description = 'Current job status and progress',
                disabled = true,
                colorScheme = 'blue',
                metadata = {
                    'Stage: ' .. string.upper(ActiveJob.stage),
                    'Type: ' .. string.upper(ActiveJob.type or 'ILLEGAL'),
                    ActiveJob.boxesCollected and ('Progress: ' .. ActiveJob.boxesCollected .. '/' .. ActiveJob.totalBoxes) or 'In Progress'
                }
            })
            
            table.insert(menuOptions, {
                title = 'Cancel Current Job',
                icon = 'fas fa-times-circle',
                description = 'Cancel your current job (no payment)',
                colorScheme = 'red',
                onSelect = function()
                    CancelJobDialog()
                end,
                metadata = {
                    'Warning: No payment will be given',
                    'Vehicles will be reclaimed'
                }
            })
        end
    end
    
    lib.registerContext({
        id = 'mkize_trucking_menu',
        title = 'Mkize Trucking Services',
        options = menuOptions
    })
    
    lib.showContext('mkize_trucking_menu')
end

function StartJobConfirmation(jobType)
    local jobDetails = {}
    local payment = ""
    local riskLevel = ""
    
    if jobType == 'illegal' then
        payment = '$' .. Config.Payment.min .. ' - $' .. Config.Payment.max
        riskLevel = 'HIGH RISK - Police will be alerted'
        jobDetails = {
            'Single dangerous cargo pickup',
            'Armed enemies at location',
            'Police response expected',
            'High damage risk to vehicle'
        }
    else
        payment = '$' .. Config.LegalJobSettings.basePayment .. '+ (multi-route bonus)'
        riskLevel = 'LOW RISK - Legal operations'
        jobDetails = {
            'Multiple safe delivery routes',
            'No hostile encounters',
            'Professional cargo handling',
            'Legitimate business operations'
        }
    end
    
    local alert = lib.alertDialog({
        header = 'Confirm Job - ' .. string.upper(jobType),
        content = string.format([[
**Job Details:**
%s

**Payment:** %s
**Risk Level:** %s

Are you ready to begin this job?
        ]], table.concat(jobDetails, '\n'), payment, riskLevel),
        centered = true,
        cancel = true,
        labels = {
            cancel = 'Not Ready',
            confirm = 'Start Job'
        }
    })
    
    if alert == 'confirm' then
        TriggerServerEvent('filthy_truckerjob:server:startJob', jobType)
    end
end

function ReturnTruckConfirmation()
    if not IsVehicleAttachedToTrailer(TruckVehicle) then
        lib.notify({
            title = 'Cannot Return Truck',
            description = Config.Notifications.truckNotAttached,
            type = 'error',
            duration = 5000
        })
        return
    end
    
    local payment = ActiveJob.type == 'illegal' and ActiveJob.payment or ActiveJob.totalPayment
    
    local alert = lib.alertDialog({
        header = 'Complete Job',
        content = string.format([[
**Job Summary:**
Type: %s
Payment: $%s

Ready to complete your job and receive payment?
        ]], string.upper(ActiveJob.type or 'ILLEGAL'), payment),
        centered = true,
        cancel = true,
        labels = {
            cancel = 'Not Yet',
            confirm = 'Complete Job'
        }
    })
    
    if alert == 'confirm' then
        TriggerServerEvent('filthy_truckerjob:server:completeJob', ActiveJob.id)
    end
end

CreateThread(function()
    GetFrameworkObject()
    Wait(1000)
    SpawnJobGiver()
    if Config.GetFramework() == 'qbox' then
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = exports.qbx_core:GetPlayerData()
        end)
        RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
            PlayerData.job = job
        end)
    else
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = Framework.Functions.GetPlayerData()
        end)
        RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
            PlayerData.job = job
        end)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    CleanupMission()
    if JobGiverPed then
        DeletePed(JobGiverPed)
    end
end)

function SpawnJobGiver()
    local coords = Config.JobGiver.coords
    
    lib.requestModel(Config.JobGiver.model, 10000)
    JobGiverPed = CreatePed(4, Config.JobGiver.model, coords.x, coords.y, coords.z - 1.0, coords.w, false, true)
    
    TaskStartScenarioInPlace(JobGiverPed, Config.JobGiver.scenario, 0, true)
    SetEntityInvincible(JobGiverPed, true)
    SetBlockingOfNonTemporaryEvents(JobGiverPed, true)
    FreezeEntityPosition(JobGiverPed, true)
   
    local blip = AddBlipForEntity(JobGiverPed)
    SetBlipSprite(blip, 477)
    SetBlipColour(blip, 5)
    SetBlipScale(blip, 0.9)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Mr. Mkize - Trucking Jobs')
    EndTextCommandSetBlipName(blip)
    
    if Config.Target == 'ox_target' then
        exports.ox_target:addLocalEntity(JobGiverPed, {
            {
                name = 'mkize_menu',
                label = Config.JobGiver.label,
                icon = Config.JobGiver.icon,
                distance = Config.JobGiver.distance,
                canInteract = function()
                    return IsJobWhitelisted()
                end,
                onSelect = function()
                    ShowMkizeMenu()
                end,
            }
        })
    elseif Config.Target == 'qb-target' then
        exports['qb-target']:AddTargetEntity(JobGiverPed, {
            options = {
                {
                    type = "client",
                    event = "filthy_truckerjob:client:showMenu",
                    icon = Config.JobGiver.icon,
                    label = Config.JobGiver.label,
                    canInteract = function()
                        return IsJobWhitelisted()
                    end,
                }
            },
            distance = Config.JobGiver.distance
        })
    else
        
        CreateThread(function()
            while DoesEntityExist(JobGiverPed) do
                local playerCoords = GetEntityCoords(PlayerPedId())
                local pedCoords = GetEntityCoords(JobGiverPed)
                local distance = #(playerCoords - pedCoords)
                
                if distance < Config.JobGiver.distance then
                    lib.showTextUI('[E] ' .. Config.JobGiver.label, {
                        position = "left-center",
                        style = {
                            borderRadius = 0,
                            backgroundColor = '#48505A',
                            color = 'white'
                        }
                    })
                    
                    if IsControlJustPressed(0, 38) then 
                        lib.hideTextUI()
                        ShowMkizeMenu()
                    end
                else
                    lib.hideTextUI()
                end
                
                Wait(500)
            end
        end)
    end
    
    DebugPrint('Job giver spawned at: ' .. tostring(coords) .. ' with blip')
end

function CancelJobDialog()
    local alert = lib.alertDialog({
        header = 'Cancel Job - ' .. Config.JobGiver.name,
        content = 'Are you sure you want to cancel your current job? You will not receive any payment and the vehicles will be reclaimed.',
        centered = true,
        cancel = true,
        labels = {
            cancel = 'Keep Job',
            confirm = 'Cancel Job'
        }
    })

    if alert == 'confirm' then
        TriggerServerEvent('filthy_truckerjob:server:cancelJob', ActiveJob.id)
    end
end

function StartJobDialog()
    ShowMkizeMenu()  
end

RegisterNetEvent('filthy_truckerjob:client:jobStarted', function(jobData)
    ActiveJob = jobData
    
    if ActiveJob.type == 'illegal' then
        ActiveJob.stage = 'connect_trailer'
        DebugPrint('Illegal job started: ' .. json.encode(jobData))
    else
        ActiveJob.stage = 'connect_trailer'
        ActiveJob.boxesCollected = 0
        ActiveJob.totalBoxes = ActiveJob.routes[ActiveJob.currentRoute].boxCount
        DebugPrint('Legal job started with ' .. #ActiveJob.routes .. ' routes')
    end
    
    SpawnTruckAndTrailer()
    ShowBriefing()
end)

function ShowBriefing()
    local briefing = ""
    
    if ActiveJob.type == 'illegal' then
        briefing = table.concat(Config.DialogueOptions.jobBriefing, '\n\n')
    else
        briefing = "Listen up, this is a legitimate cargo delivery job.\n\n" ..
                  "You'll be making " .. #ActiveJob.routes .. " delivery routes today.\n\n" ..
                  "Pick up the cargo from each location, deliver it, then move to the next route.\n\n" ..
                  "Complete all routes and return the truck for your full payment of $" .. ActiveJob.totalPayment .. "."
    end
    
    lib.alertDialog({
        header = 'Job Briefing - ' .. Config.JobGiver.name,
        content = briefing,
        centered = true,
        cancel = false
    })
    
    ShowNotification(Config.Notifications.missionStarted, 'inform', 8000)
end

function SpawnTruckAndTrailer()
    local spawnCoords = Config.TruckSpawn
    
    SpawnVehicleWithSetup({
        model = Config.Vehicles.truck,
        coords = spawnCoords,
        label = 'Delivery Truck',
        callback = function(vehicle)
            TruckVehicle = vehicle
           
            local trailerCoords = vec4(spawnCoords.x - 10.0, spawnCoords.y, spawnCoords.z, spawnCoords.w)
            SpawnVehicleWithSetup({
                model = Config.Vehicles.trailer,
                coords = trailerCoords,
                label = 'Cargo Trailer',
                callback = function(trailer)
                    TrailerVehicle = trailer
                    DebugPrint('Both vehicles spawned successfully')
                end
            })
        end
    })
    
    CreateThread(function()
        while ActiveJob and ActiveJob.stage == 'connect_trailer' do
            if TruckVehicle and TrailerVehicle and IsVehicleAttachedToTrailer(TruckVehicle) then
                ActiveJob.stage = 'goto_pickup'
                CreatePickupBlip()
                ShowNotification('Trailer connected! Head to the pickup location', 'success')
                
                MonitorTrailerDamage()
                break
            end
            Wait(1000)
        end
    end)
end

function SpawnVehicleWithSetup(data)
    local spawnCoords = data.coords
    local settings = Config.VehicleSettings
    
    if not spawnCoords or not spawnCoords.x then
        ShowNotification('Config Error: Invalid spawn coordinates', 'error')
        DebugPrint('Invalid spawn coordinates in SpawnVehicleWithSetup')
        return
    end
    
    local x, y, z, w = spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnCoords.w
    local checkDistance = settings.CheckDistance or 3.0
    
    local oldVeh = GetClosestVehicle(x, y, z, checkDistance, 0, 71)
    if oldVeh ~= 0 then
        ShowNotification('Spawn Blocked: Move the vehicle from the spawn point', 'error')
        DebugPrint('Spawn area blocked by existing vehicle')
        return
    end
    
    lib.requestModel(data.model, 10000)
    
    local vehicle = CreateVehicle(GetHashKey(data.model), x, y, z, w, true, false)
    
    local timeout = 0
    while not DoesEntityExist(vehicle) and timeout < 50 do
        Wait(100)
        timeout = timeout + 1
    end
    
    if not DoesEntityExist(vehicle) then
        ShowNotification('Spawn Failed: Failed to create vehicle', 'error')
        DebugPrint('Failed to create vehicle: ' .. data.model)
        return
    end
    
    local platePrefix = settings.PlatePrefix or "FTRUCK"
    local plateNumber = tostring(math.random(100, 999))
    local plate = platePrefix .. plateNumber
    
    SetVehicleNumberPlateText(vehicle, plate)
    SetEntityHeading(vehicle, w)
    SetEntityAsMissionEntity(vehicle, true, true)
    
    if settings.SpawnInVehicle and data.model == Config.Vehicles.truck then
        TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
    end
    
    local fuelLevel = settings.FuelLevel or 100.0
    if settings.FuelScript and GetResourceState(settings.FuelScript) == 'started' then
        if settings.FuelScript == 'lc_fuel' then
            exports.lc_fuel:SetFuel(vehicle, fuelLevel)
        elseif settings.FuelScript == 'ox_fuel' then
            Entity(vehicle).state.fuel = fuelLevel
        elseif settings.FuelScript == 'ps-fuel' then
            exports['ps-fuel']:SetFuel(vehicle, fuelLevel)
        elseif settings.FuelScript == 'cdn-fuel' then
            exports['cdn-fuel']:SetFuel(vehicle, fuelLevel)
        end
        DebugPrint('Set fuel using ' .. settings.FuelScript .. ': ' .. fuelLevel .. '%')
    else
        SetVehicleFuelLevel(vehicle, fuelLevel)
        DebugPrint('Set fuel using native function: ' .. fuelLevel .. '%')
    end
    
    local vehiclePlate = GetVehicleNumberPlateText(vehicle)
    if settings.KeysScript and GetResourceState(settings.KeysScript) == 'started' then
        if settings.KeysScript == 'qb-vehiclekeys' then
            TriggerEvent("vehiclekeys:client:SetOwner", vehiclePlate)
        elseif settings.KeysScript == 'wasabi_carlock' then
            exports.wasabi_carlock:GiveKey(vehiclePlate)
        elseif settings.KeysScript == 'cd_garage' then
            TriggerEvent('cd_garage:AddKeys', exports.cd_garage:GetPlate(vehicle))
        end
        DebugPrint('Gave keys using ' .. settings.KeysScript .. ' for plate: ' .. vehiclePlate)
    else
        if Config.GetFramework() == 'qbox' then
            TriggerEvent("vehiclekeys:client:SetOwner", vehiclePlate)
        else
            TriggerEvent("vehiclekeys:client:SetOwner", vehiclePlate)
        end
        DebugPrint('Gave keys using framework fallback for plate: ' .. vehiclePlate)
    end
    
    SetVehicleEngineOn(vehicle, settings.EngineOn or true, true, false)
    SetVehicleDirtLevel(vehicle, settings.DirtLevel or 0.0)
    
    ShowNotification(data.label .. ' spawned - Plate: ' .. plate, 'success')
    DebugPrint('Vehicle spawned: ' .. data.model .. ' with plate: ' .. plate)
    
    if data.callback then
        data.callback(vehicle)
    end
    
    return vehicle
end

function CreatePickupBlip()
    if not ActiveJob or not ActiveJob.pickupLocation then return end
    
    local coords = ActiveJob.pickupLocation.coords
    
    ActiveJob.pickupBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(ActiveJob.pickupBlip, 478)
    SetBlipColour(ActiveJob.pickupBlip, 5)
    SetBlipScale(ActiveJob.pickupBlip, 1.0)
    SetBlipRoute(ActiveJob.pickupBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Pickup Location')
    EndTextCommandSetBlipName(ActiveJob.pickupBlip)
    
    CreatePickupZone()
    DebugPrint('Pickup blip created')
end

function CreatePickupZone()
    if not ActiveJob or not ActiveJob.pickupLocation then return end
    
    local coords = ActiveJob.pickupLocation.coords
    
    PickupZone = lib.zones.sphere({
        coords = vec3(coords.x, coords.y, coords.z),
        radius = 50.0,
        debug = Config.Debug,
        onEnter = function()
            if ActiveJob and ActiveJob.stage == 'goto_pickup' then
                StartPickupPhase()
            end
        end
    })
end

function StartPickupPhase()
    DebugPrint('Starting pickup phase')
    
    if ActiveJob.type == 'illegal' then
        ActiveJob.stage = 'collecting'
        ActiveJob.boxesCollected = 0
        ActiveJob.totalBoxes = ActiveJob.pickupLocation.boxCount
        
        RemoveBlip(ActiveJob.pickupBlip)
        SpawnBoxes()
        SpawnEnemies()
        
        ShowNotification(Config.Notifications.enemiesIncoming, 'error', 5000)
        TriggerServerEvent('filthy_truckerjob:server:alertPolice', ActiveJob.pickupLocation.coords)
    else
        ActiveJob.stage = 'legal_collecting'
        ActiveJob.boxesCollected = 0
        ActiveJob.totalBoxes = ActiveJob.routes[ActiveJob.currentRoute].boxCount
        
        RemoveBlip(ActiveJob.pickupBlip)
        SpawnBoxes()
        
        local currentRoute = ActiveJob.routes[ActiveJob.currentRoute]
        ShowNotification('Collecting cargo for: ' .. currentRoute.name, 'inform', 5000)
    end
end

function SpawnBoxes()
    local location = ActiveJob.pickupLocation
    Boxes = {}
    BoxBlips = {}
    
    local playerOffset = GetPlayerServerId(PlayerId()) * 0.5 
    
    for i = 1, location.boxCount do
        if location.boxSpawns[i] then
            local coords = location.boxSpawns[i]
            
            local offsetX = coords.x + math.random(-1, 1) + (playerOffset * math.cos(i))
            local offsetY = coords.y + math.random(-1, 1) + (playerOffset * math.sin(i))
            local offsetZ = coords.z
            
            lib.requestModel(Config.Boxes.prop, 5000)
            local box = CreateObject(Config.Boxes.prop, offsetX, offsetY, offsetZ, true, false, true)
            PlaceObjectOnGroundProperly(box)
            
            Boxes[i] = {
                object = box,
                coords = GetEntityCoords(box),
                collected = false
            }
            
            local blip = AddBlipForEntity(box)
            SetBlipSprite(blip, 586)
            SetBlipColour(blip, 2)
            SetBlipScale(blip, 0.8)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentString('Package')
            EndTextCommandSetBlipName(blip)
            BoxBlips[i] = blip
            
            if Config.Target == 'ox_target' then
                exports.ox_target:addLocalEntity(box, {
                    name = 'collect_box_' .. i,
                    label = Config.Boxes.label,
                    icon = Config.Boxes.icon,
                    distance = 3.0,
                    canInteract = function()
                        return not Boxes[i].collected and not CarriedBox
                    end,
                    onSelect = function()
                        CollectBox(i)
                    end,
                })
            elseif Config.Target == 'qb-target' then
                exports['qb-target']:AddTargetEntity(box, {
                    options = {
                        {
                            type = "client",
                            event = "filthy_truckerjob:client:collectBox",
                            icon = Config.Boxes.icon,
                            label = Config.Boxes.label,
                            canInteract = function()
                                return not Boxes[i].collected and not CarriedBox
                            end,
                            boxIndex = i
                        }
                    },
                    distance = 3.0
                })
            end
        end
    end
    
    DebugPrint('Spawned ' .. #Boxes .. ' boxes with target system and player-specific offsets')
end

function CollectBox(index)
    if CarriedBox or Boxes[index].collected then return end
    
    local box = Boxes[index]
    if not DoesEntityExist(box.object) then return end
    
    if lib.progressCircle({
        duration = Config.Boxes.collectTime,
        label = 'Collecting package...',
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            move = true,
            car = true,
            combat = true,
        },
        anim = {
            dict = 'pickup_object',
            clip = 'pickup_low',
        },
    }) then
    
        Boxes[index].collected = true
        DeleteEntity(box.object)
        RemoveBlip(BoxBlips[index])
        
        if Config.Target == 'ox_target' then
            exports.ox_target:removeLocalEntity(box.object, 'collect_box_' .. index)
        elseif Config.Target == 'qb-target' then
            exports['qb-target']:RemoveTargetEntity(box.object)
        end
        
        CarriedBox = CreateObject(Config.Boxes.prop, 0, 0, 0, true, true, true)
        AttachEntityToEntity(CarriedBox, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 60309), 0.025, 0.08, 0.255, -145.0, 290.0, 0.0, true, true, false, true, 1, true)
        
        lib.requestAnimDict(Config.Boxes.carryAnim.dict)
        TaskPlayAnim(PlayerPedId(), Config.Boxes.carryAnim.dict, Config.Boxes.carryAnim.clip, 8.0, 8.0, -1, Config.Boxes.carryAnim.flag, 0, false, false, false)
        
        ActiveJob.boxesCollected = ActiveJob.boxesCollected + 1
        local remaining = ActiveJob.totalBoxes - ActiveJob.boxesCollected
        
        ShowNotification('Package collected! Go to the back of the trailer to load it', 'success')
        
        MonitorTrailerDeposit()
        
        DebugPrint('Box collected. Progress: ' .. ActiveJob.boxesCollected .. '/' .. ActiveJob.totalBoxes)
    end
end

function MonitorTrailerDeposit()
    CreateThread(function()
        local trailerZone = nil
        
        if TrailerVehicle and DoesEntityExist(TrailerVehicle) then
            local trailerCoords = GetEntityCoords(TrailerVehicle)
            
            trailerZone = lib.zones.sphere({
                coords = vec3(trailerCoords.x, trailerCoords.y, trailerCoords.z),
                radius = 10.0, 
                debug = Config.Debug,
                inside = function()
                    if CarriedBox then
                        lib.showTextUI('[E] Load package into trailer', {
                            position = "left-center",
                            style = {
                                borderRadius = 0,
                                backgroundColor = '#48505A',
                                color = 'white'
                            }
                        })
                        
                        if IsControlJustPressed(0, 38) then 
                            lib.hideTextUI()
                            if trailerZone then
                                trailerZone:remove()
                            end
                            DepositBox()
                        end
                    end
                end,
                onExit = function()
                    lib.hideTextUI()
                end
            })
        end
        
        while CarriedBox and DoesEntityExist(CarriedBox) do
            Wait(1000)
        end
        
        if trailerZone then
            trailerZone:remove()
        end
    end)
end

function DepositBox()
    if not CarriedBox then return end
    
    if lib.progressCircle({
        duration = 3000,
        label = 'Loading package into trailer...',
        position = 'bottom',
        useWhileDead = false,
        canCancel = false,
        disable = {
            move = true,
            car = true,
            combat = true,
        },
        anim = {
            dict = 'pickup_object',
            clip = 'putdown_low',
        },
    }) then
        
        DeleteEntity(CarriedBox)
        CarriedBox = nil
        ClearPedTasks(PlayerPedId())
        
        ShowNotification('Package loaded successfully!', 'success')
       
        if ActiveJob.boxesCollected >= ActiveJob.totalBoxes then
            AllBoxesCollected()
        else
           
            local remaining = ActiveJob.totalBoxes - ActiveJob.boxesCollected
            ShowNotification('Packages remaining: ' .. remaining .. '. Continue collecting!', 'inform', 5000)
        end
    end
end

function AllBoxesCollected()
    if ActiveJob.type == 'illegal' then
        ActiveJob.stage = 'delivery'
        ShowNotification(Config.Notifications.allBoxesCollected, 'success', 8000)
        
        CleanupEnemies()
        CreateDeliveryBlip()
    else
        ActiveJob.stage = 'legal_delivery'
        local currentRoute = ActiveJob.routes[ActiveJob.currentRoute]
        ShowNotification('All cargo loaded! Deliver to: ' .. currentRoute.name, 'success', 8000)
        
        CreateLegalDeliveryBlip()
    end
    
    DebugPrint('All boxes collected, moving to delivery phase')
end

function SpawnEnemies()
    local location = ActiveJob.pickupLocation
    Enemies = {}
    
    for i = 1, location.enemyCount do
        if location.enemySpawns[i] then
            CreateThread(function()
                Wait(math.random(5000, 15000)) 
                SpawnEnemy(location.enemySpawns[i], i)
            end)
        end
    end
end

function SpawnEnemy(coords, index)
    local model = Config.Enemies.models[math.random(1, #Config.Enemies.models)]
    local weapon = Config.Enemies.weapons[math.random(1, #Config.Enemies.weapons)]
    local vehicle = Config.Enemies.vehicles[math.random(1, #Config.Enemies.vehicles)]
    
    lib.requestModel(vehicle, 5000)
    local enemyVeh = CreateVehicle(vehicle, coords.x, coords.y, coords.z, math.random(0, 360), true, false)
    SetEntityAsMissionEntity(enemyVeh, true, true)
    
    lib.requestModel(model, 5000)
    local enemy = CreatePedInsideVehicle(enemyVeh, 26, model, -1, true, false)
    
    SetPedMaxHealth(enemy, Config.Enemies.health)
    SetEntityHealth(enemy, Config.Enemies.health)
    SetPedArmour(enemy, Config.Enemies.armor)
    SetPedAccuracy(enemy, Config.Enemies.accuracy)
    SetPedFleeAttributes(enemy, 0, false)
    SetPedCombatAttributes(enemy, 46, true)
    SetPedCombatAbility(enemy, 2)
    SetPedCombatMovement(enemy, 2)
    SetPedKeepTask(enemy, true)
    SetPedDropsWeaponsWhenDead(enemy, false)
    
    GiveWeaponToPed(enemy, GetHashKey(weapon), 250, false, true)
    
    SetPedRelationshipGroupHash(enemy, GetHashKey('HATES_PLAYER'))
    SetRelationshipBetweenGroups(5, GetHashKey('HATES_PLAYER'), GetHashKey('PLAYER'))
    
    TaskCombatPed(enemy, PlayerPedId(), 0, 16)
    
    Enemies[index] = {
        ped = enemy,
        vehicle = enemyVeh
    }
    
    DebugPrint('Enemy ' .. index .. ' spawned with ' .. weapon)
end

function CleanupEnemies()
    for i, enemy in pairs(Enemies) do
        if DoesEntityExist(enemy.ped) then
            DeleteEntity(enemy.ped)
        end
        if DoesEntityExist(enemy.vehicle) then
            DeleteEntity(enemy.vehicle)
        end
    end
    Enemies = {}
    DebugPrint('Enemies cleaned up')
end

function CreateDeliveryBlip()
    if not ActiveJob or not ActiveJob.deliveryLocation then return end
    
    local coords = ActiveJob.deliveryLocation
    
    DeliveryBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(DeliveryBlip, 501)
    SetBlipColour(DeliveryBlip, 3)
    SetBlipScale(DeliveryBlip, 1.0)
    SetBlipRoute(DeliveryBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Delivery Point')
    EndTextCommandSetBlipName(DeliveryBlip)
    
    CreateDeliveryZone()
    DebugPrint('Delivery blip created')
end

function CreateDeliveryZone()
    if not ActiveJob or not ActiveJob.deliveryLocation then return end
    
    local coords = ActiveJob.deliveryLocation
    
    local deliveryZone = lib.zones.sphere({
        coords = vec3(coords.x, coords.y, coords.z),
        radius = 15.0,
        debug = Config.Debug,
        onEnter = function()
            if ActiveJob and ActiveJob.stage == 'delivery' and IsVehicleAttachedToTrailer(TruckVehicle) then
                CompleteDelivery()
            end
        end
    })
    
    ActiveJob.deliveryZone = deliveryZone
end

function CompleteDelivery()
    if ActiveJob.stage ~= 'delivery' then return end
    
    ActiveJob.stage = 'return'
    RemoveBlip(DeliveryBlip)
    
    if ActiveJob.deliveryZone then
        ActiveJob.deliveryZone:remove()
    end
    
    ShowNotification(Config.Notifications.deliveryComplete, 'success', 8000)
    CreateReturnBlip()
    
    DebugPrint('Delivery completed')
end

function CreateLegalDeliveryBlip()
    if not ActiveJob or not ActiveJob.routes or not ActiveJob.routes[ActiveJob.currentRoute] then return end
    
    local route = ActiveJob.routes[ActiveJob.currentRoute]
    local coords = route.delivery
    
    DeliveryBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(DeliveryBlip, 501)
    SetBlipColour(DeliveryBlip, 3)
    SetBlipScale(DeliveryBlip, 1.0)
    SetBlipRoute(DeliveryBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Delivery: ' .. route.name)
    EndTextCommandSetBlipName(DeliveryBlip)
    
    CreateLegalDeliveryZone()
    DebugPrint('Legal delivery blip created for route: ' .. route.name)
end

function CreateLegalDeliveryZone()
    if not ActiveJob or not ActiveJob.routes or not ActiveJob.routes[ActiveJob.currentRoute] then return end
    
    local route = ActiveJob.routes[ActiveJob.currentRoute]
    local coords = route.delivery
    
    local deliveryZone = lib.zones.sphere({
        coords = vec3(coords.x, coords.y, coords.z),
        radius = 15.0,
        debug = Config.Debug,
        onEnter = function()
            if ActiveJob and ActiveJob.stage == 'legal_delivery' and IsVehicleAttachedToTrailer(TruckVehicle) then
                CompleteLegalDelivery()
            end
        end
    })
    
    ActiveJob.deliveryZone = deliveryZone
end

function CompleteLegalDelivery()
    if ActiveJob.stage ~= 'legal_delivery' then return end
    
    local currentRoute = ActiveJob.routes[ActiveJob.currentRoute]
    currentRoute.completed = true
    ActiveJob.routesCompleted = ActiveJob.routesCompleted + 1
    
    RemoveBlip(DeliveryBlip)
    if ActiveJob.deliveryZone then
        ActiveJob.deliveryZone:remove()
    end
    
    ShowNotification('Route ' .. ActiveJob.currentRoute .. ' completed: ' .. currentRoute.name, 'success', 5000)
    
    if ActiveJob.currentRoute < #ActiveJob.routes then
        
        ActiveJob.currentRoute = ActiveJob.currentRoute + 1
        ActiveJob.boxesCollected = 0
        ActiveJob.totalBoxes = ActiveJob.routes[ActiveJob.currentRoute].boxCount
        
        ActiveJob.pickupLocation = CreateLegalPickupLocation(ActiveJob.routes[ActiveJob.currentRoute])
        ActiveJob.stage = 'goto_pickup'
        
        CreatePickupBlip()
        ShowNotification('Next route: ' .. ActiveJob.routes[ActiveJob.currentRoute].name, 'inform', 8000)
    else
        ActiveJob.stage = 'return'
        ShowNotification('All routes completed! Return the truck to Mr. Mkize for payment ($' .. ActiveJob.totalPayment .. ')', 'success', 10000)
        CreateReturnBlip()
    end
    
    DebugPrint('Legal delivery completed. Route ' .. (ActiveJob.currentRoute - 1) .. ' finished')
end

function CreateLegalPickupLocation(route)
   
    local boxSpawns = {}
    local pickup = route.pickup
    
    for i = 1, route.boxCount do
        local angle = (i - 1) * (360 / route.boxCount)
        local radian = math.rad(angle)
        local distance = math.random(3, 8)
        
        local x = pickup.x + math.cos(radian) * distance
        local y = pickup.y + math.sin(radian) * distance
        local z = pickup.z
        
        table.insert(boxSpawns, vec3(x, y, z))
    end
    
    return {
        name = route.name,
        coords = pickup,
        boxCount = route.boxCount,
        boxSpawns = boxSpawns,
        enemyCount = 0, 
        enemySpawns = {}
    }
end

function CreateReturnBlip()
    local coords = Config.JobGiver.coords
    
    ReturnBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(ReturnBlip, 479)
    SetBlipColour(ReturnBlip, 2)
    SetBlipScale(ReturnBlip, 1.0)
    SetBlipRoute(ReturnBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Return to Mr. Mkize')
    EndTextCommandSetBlipName(ReturnBlip)
    
    DebugPrint('Return blip created')
end

function MonitorTrailerDamage()
    CreateThread(function()
        local damageThreshold = 500.0 
        local lastWarningTime = 0
        
        while ActiveJob and TrailerVehicle and DoesEntityExist(TrailerVehicle) do
            local trailerHealth = GetEntityHealth(TrailerVehicle)
            local maxHealth = GetEntityMaxHealth(TrailerVehicle)
            local healthPercentage = (trailerHealth / maxHealth) * 100
            
            if healthPercentage < 50 and GetGameTimer() - lastWarningTime > 10000 then
                ShowNotification('Warning: Trailer is heavily damaged! Avoid further damage or the job will fail!', 'error', 8000)
                lastWarningTime = GetGameTimer()
            end
            
            if trailerHealth < damageThreshold then
                ShowNotification('Trailer destroyed! Job failed - no payment will be given.', 'error', 10000)
                TriggerServerEvent('filthy_truckerjob:server:failJob', ActiveJob.id, 'Trailer was destroyed')
                break
            end
            
            Wait(1000)
        end
    end)
end

function ReturnTruck()
    if not ActiveJob or ActiveJob.stage ~= 'return' then return end
    
    if not IsVehicleAttachedToTrailer(TruckVehicle) then
        ShowNotification(Config.Notifications.truckNotAttached, 'error')
        return
    end
    
    TriggerServerEvent('filthy_truckerjob:server:completeJob', ActiveJob.id)
end

RegisterNetEvent('filthy_truckerjob:client:jobCompleted', function(payment)
    ShowNotification(string.format(Config.Notifications.jobCompleted, payment), 'success', 10000)

    local completion = table.concat(Config.DialogueOptions.completion, '\n\n')

    lib.alertDialog({
        header = 'Job Complete - ' .. Config.JobGiver.name,
        content = completion .. '\n\nPayment: ' .. payment,
        centered = true,
        cancel = false
    })

    CleanupMission()
    DebugPrint('Job completed with payment: ' .. payment)
end)

RegisterNetEvent('filthy_truckerjob:client:jobFailed', function(reason)
    ShowNotification(reason or Config.Notifications.missionFailed, 'error', 8000)
    CleanupMission()
    DebugPrint('Job failed: ' .. (reason or 'Unknown reason'))
end)

RegisterNetEvent('filthy_truckerjob:client:jobCancelled', function()
    ShowNotification('Job cancelled. Vehicles have been reclaimed.', 'inform', 8000)
    
    lib.alertDialog({
        header = 'Job Cancelled - ' .. Config.JobGiver.name,
        content = 'Your job has been cancelled. The vehicles have been reclaimed and no payment has been made.',
        centered = true,
        cancel = false
    })
    
    CleanupMission()
    DebugPrint('Job cancelled by player')
end)

function CleanupMission()
    DebugPrint('Cleaning up mission')
    lib.hideTextUI()
    
    if ActiveJob then
        if ActiveJob.pickupBlip then RemoveBlip(ActiveJob.pickupBlip) end
        if ActiveJob.deliveryZone then ActiveJob.deliveryZone:remove() end
    end
    if DeliveryBlip then RemoveBlip(DeliveryBlip) end
    if ReturnBlip then RemoveBlip(ReturnBlip) end
    
    if PickupZone then
        PickupZone:remove()
        PickupZone = nil
    end
    
    for i, box in pairs(Boxes) do
        if DoesEntityExist(box.object) then
            if Config.Target == 'ox_target' then
                exports.ox_target:removeLocalEntity(box.object, 'collect_box_' .. i)
            elseif Config.Target == 'qb-target' then
                exports['qb-target']:RemoveTargetEntity(box.object)
            end
            DeleteEntity(box.object)
        end
        if BoxBlips[i] then
            RemoveBlip(BoxBlips[i])
        end
    end
    Boxes = {}
    BoxBlips = {}
    
    if CarriedBox and DoesEntityExist(CarriedBox) then
        DeleteEntity(CarriedBox)
        CarriedBox = nil
        ClearPedTasks(PlayerPedId())
    end
    
    CleanupEnemies()
    if TruckVehicle and DoesEntityExist(TruckVehicle) then
        DeleteEntity(TruckVehicle)
        TruckVehicle = nil
    end
    if TrailerVehicle and DoesEntityExist(TrailerVehicle) then
        DeleteEntity(TrailerVehicle)
        TrailerVehicle = nil
    end
    
    ActiveJob = nil
    DebugPrint('Mission cleanup completed')
end

RegisterNetEvent('filthy_truckerjob:client:showMenu', function()
    ShowMkizeMenu()
end)

RegisterNetEvent('filthy_truckerjob:client:collectBox', function(data)
    if data.boxIndex then
        CollectBox(data.boxIndex)
    end
end)


Config = {}
Config.Debug = false
Config.Framework = 'auto' -- 'qbcore', 'qbox', or 'auto'
Config.Target = 'ox_target'-- Target system ('ox_target', 'qb-target')
Config.Dispatch = 'cd_dispatch'-- Dispatch system ('cd_dispatch', 'ps-dispatch', 'custom' or 'none')
Config.MaxActiveJobs = 3
Config.JobCooldown = 15
Config.Payment = {
    min = 15000,
    max = 35000
}
Config.RequiredPolice = 0
Config.JobGiver = {
    model = 's_m_m_trucker_01',
    coords = vec4(-374.79, -2730.53, 6.04, 165.99),
    scenario = 'WORLD_HUMAN_CLIPBOARD',
    name = 'Mr. Mkize',
    label = 'Talk to Mr. Mkize',
    icon = 'fa-solid fa-truck',
    distance = 2.5,
    dialogue = {
        "Sawubona my friend, looking for some quick cash?",
        "I got some special deliveries that need... discrete handling.",
        "These routes pay well, but they're not exactly legal, understand?",
        "You handle this right, and there's good money to be made.",
        "The authorities can't know about this business, keep it quiet."
    }
}
Config.Vehicles = {
    truck = 'phantom3',
    trailer = 'trailers2'
}

Config.VehicleSettings = {
    FuelScript = 'lc_fuel', -- 'legacy-fuel','lc_fuel', 'ox_fuel', 'ps-fuel', 'cdn-fuel', or nil for default
    KeysScript = 'qb-vehiclekeys', -- 'qb-vehiclekeys', 'wasabi_carlock', 'cd_keys', or nil(leave as qb-vehiclekeys for qbox )
    FuelLevel = 100.0, -- Starting fuel level (0-100)
    CheckDistance = 3.0, -- Distance to check for blocking vehicles
    PlatePrefix = "FILTHY", -- Custom Plate for spawned trucks
    SpawnInVehicle = false, -- Put player in vehicle when spawned(RECOMENDED)
    DirtLevel = 0.0, -- Vehicle dirt level (0.0 = clean, 15.0 = very dirty if you want to be fancy
    EngineOn = true -- Start with engine on
}
Config.TruckSpawn = vec4(-388.77, -2712.94, 6.0, 236.17)
Config.PickupLocations = {
    {
        name = "Sandy Shores Warehouse",
        coords = vec3(1975.5, 3815.2, 33.4),
        heading = 120.0,
        boxCount = math.random(3, 8),
        enemyCount = math.random(3, 6),
        boxSpawns = {
            vec3(1954.21, 3846.96, 32.02),
            vec3(1972.8, 3818.5, 33.4),
            vec3(1969.51, 3787.15, 32.26),
            vec3(1977.9, 3815.2, 33.4),
            vec3(1980.2, 3813.6, 33.4),
            vec3(1982.8, 3812.1, 33.4),
            vec3(1985.1, 3810.5, 33.4),
            vec3(1956.86, 3814.2, 32.4),
            vec3(1989.8, 3807.3, 33.4),
            vec3(1987.1, 3839.19, 32.24),
            vec3(1973.63, 3827.15, 32.37),
            vec3(1964.08, 3807.01, 32.38)
        },
        enemySpawns = {
            vec3(1967.27, 3817.54, 36.56),
            vec3(1952.65, 3853.64, 31.98),
            vec3(1988.13, 3862.95, 32.25),
            vec3(1936.89, 3784.88, 32.27),
            vec3(2017.06, 3798.48, 32.28),
            vec3(1936.63, 3862.21, 32.36)
        }
    },
    {
        name = "Grapeseed Airfield",
        coords = vec3(2121.8, 4796.5, 41.0),
        heading = 200.0,
        boxCount = math.random(6, 10),
        enemyCount = math.random(2, 5),
        boxSpawns = {
            vec3(2125.2, 4800.1, 41.0),
            vec3(2127.8, 4798.5, 41.0),
            vec3(2130.1, 4796.8, 41.0),
            vec3(2132.9, 4795.2, 41.0),
            vec3(2135.2, 4793.6, 41.0),
            vec3(2137.8, 4792.1, 41.0),
            vec3(2140.1, 4790.5, 41.0),
            vec3(2142.5, 4788.9, 41.0),
            vec3(2144.8, 4787.3, 41.0),
            vec3(2147.2, 4785.8, 41.0)
        },
        enemySpawns = {
            vec3(2110.0, 4805.0, 41.0),
            vec3(2150.0, 4780.0, 41.0),
            vec3(2140.0, 4800.0, 41.0),
            vec3(2115.0, 4790.0, 41.0),
            vec3(2155.0, 4795.0, 41.0)
        }
    },
    {
        name = "Pops Diner",
        coords = vector3(1598.83, 6540.48, 15.01),
        heading = 187.0,
        boxCount = math.random(2, 6),
        enemyCount = math.random(4, 7),
        boxSpawns = {
            vec3(1581.44, 6550.9, 15.72),
            vec3(1604.53, 6573.32, 15.04),
            vec3(1568.98, 6527.39, 19.13),
            vec3(1613.57, 6518.29, 18.1),
            vec3(1575.24, 6594.17, 14.39),
            vec3(1587.29, 6607.08, 15.03),
            vec3(1553.24, 6566.6, 19.74),
            vec3(1582.35, 6610.7, 14.59),
            vec3(1624.64, 6602.2, 19.65),
            vec3(1608.78, 6540.5, 15.89),
            vec3(1564.71, 6567.12, 17.83)
        },
        enemySpawns = {
            vec3(1554.87, 6557.09, 21.29),
            vec3(1636.54, 6603.22, 22.84),
            vec3(1557.08, 6605.61, 6.87),
            vec3(1579.45, 6581.54, 14.35),
            vec3(1597.7, 6563.26, 13.52),
            vec3(1588.48, 6521.56, 16.8),
            vec3(1580.58, 6469.57, 25.13)
        }
    }
}
Config.DeliveryLocations = {
    vec4(719.95, 4176.51, 40.71, 91.63),
    vec4(2467.21, 4958.32, 45.09, 125.45),
    vec4(-2201.8, 4254.55, 47.68, 328.04),
    vec4(1582.83, 6442.14, 24.99, 64.16),
    vec4(-1016.23, 4951.14, 197.84, 124.88)
}
Config.LegalDeliveryRoutes = {
    {
        name = "Port to City Route",
        pickup = vec3(1018.18, -3187.65, 5.9),
        delivery = vec3(146.17, -1074.29, 29.19),
        payment = math.random(1500, 25000)
    },
    {
        name = "Industrial to Suburb Route", 
        pickup = vec3(2533.8, 2621.2, 37.9),
        delivery = vec3(-1037.2, -2738.9, 20.2),
        payment = math.random(1800, 28000)
    },
    {
        name = "Airport Cargo Route",
        pickup = vec3(-1336.8, -3044.2, 13.9),
        delivery = vec3(797.2, -1798.5, 29.3),
        payment = math.random(2000, 30000)
    },
    {
        name = "Downtown Distribution",
        pickup = vec3(715.2, -1371.8, 26.3),
        delivery = vec3(-2202.27, 4253.98, 47.64),
        payment = math.random(2200, 32000)
    },
    {
        name = "Sandy Shores Supply Run",
        pickup = vec3(1533.8, 3540.82, 35.36),
        delivery = vec3(-1142.8, 2664.2, 18.1),
        payment = math.random(2500, 35000)
    }
}

Config.LegalJobSettings = {
    routesPerJob = math.random(1, 2),
    boxesPerRoute = math.random(3, 6),
    basePayment = math.random(8000, 15000),
    routePayment = math.random(500, 1000)
}
Config.Enemies = {
    models = {
        'g_m_m_mexboss_01',
        'g_m_m_mexboss_02',
        'g_m_y_mexgang_01',
        'g_m_y_mexgoon_01',
        'g_m_y_mexgoon_02'
    },
    weapons = {
        'WEAPON_PISTOL',
        'WEAPON_SMG',
        'WEAPON_ASSAULTRIFLE',
        'WEAPON_COMBATPISTOL'
    },
    vehicles = {
        'sanchez',
        'sanchez2',
        'enduro',
        'manchez'
    },
    accuracy = 35,
    health = 150,
    armor = 50
}
Config.Boxes = {
    prop = 'xm3_prop_xm3_crate_supp_01a',
    carryAnim = {
        dict = 'anim@heists@box_carry@',
        clip = 'idle',
        flag = 49
    },
    collectTime = 2000, 
    label = 'Collect Package',
    icon = 'fa-solid fa-box'
}
Config.DispatchSettings = {
    jobs = {'police', 'sheriff', 'ranger'}, 
    title = 'Suspicious Activity',
    message = 'Reports of armed individuals and suspicious cargo activity',
    blip = {
        sprite = 161,
        color = 1,
        scale = 1.2,
        time = 300 
    }
}
Config.DialogueOptions = {
    startJob = {
        question = "Want to make some quick cash with a special delivery?",
        accept = "Yes, I'm interested",
        decline = "Not today, thanks"
    },
    jobBriefing = {
        "Listen carefully, this isn't your typical delivery job.",
        "Pick up the packages from the marked location - they're... sensitive cargo.",
        "Watch out for competition, they don't like sharing their territory.",
        "Deliver everything to the drop-off point and bring my truck back in one piece.",
        "Do this right and you'll be compensated well. Mess it up... well, don't."
    },
    completion = {
        "Excellent work! The client is very satisfied.",
        "Your payment has been transferred no paper trail, naturally.",
        "Come back later if you want more work like this.",
        "Keep this between us, understand?"
    }
}
Config.Notifications = {
    noPolice = "Not enough police online for this operation",
    jobActive = "Already have an active job running",
    truckNotAttached = "Attach the trailer to your truck first",
    missionStarted = "Head to the pickup location marked on your GPS",
    boxCollected = "Package collected. Remaining: %s",
    allBoxesCollected = "All packages loaded! Head to the delivery point",
    enemiesIncoming = "Hostile contacts incoming! Defend yourself!",
    deliveryComplete = "Delivery completed! Return the truck to Mr. Mkize",
    jobCompleted = "Job completed successfully! Payment: $%s",
    missionFailed = "Mission failed! Return to try again"
}
-- =============================================================================
-- FRAMEWORK DETECTION FUNCTION DONT FUCKEN TOUCH !!!!!!!
-- =============================================================================
function Config.GetFramework()
    if Config.Framework == 'auto' then
        if GetResourceState('qb-core') == 'started' then
            return 'qbcore'
        elseif GetResourceState('qbx_core') == 'started' then
            return 'qbox'
        else
            return 'qbcore' 
        end
    else
        return Config.Framework
    end
end
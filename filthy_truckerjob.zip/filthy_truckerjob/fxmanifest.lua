fx_version 'cerulean'
game 'gta5'

name "filthy_truckerjob"
author "Filthy_Lytiez"
description 'Illegal Trucking Job Script by Filthy_Lytiez'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    --'@lation_ui/init.lua',--uncoment if you use lation ui
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'ox_lib'
}

lua54 'yes'
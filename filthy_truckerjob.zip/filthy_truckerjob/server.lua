local Framework = nil
local ActiveJobs = {}
local JobCooldowns = {}
local nextJobId = 1

print('^2[FILTHY LYTIEZ DEVELOPMENT]^7 Filthy Trucking Job Script Loaded Successfully!')

local function GetFrameworkObject()
    local fw = Config.GetFramework()
    if fw == 'qbox' then
        Framework = exports.qbx_core
        return exports.qbx_core
    else
        Framework = exports['qb-core']:GetCoreObject()
        return Framework
    end
end

CreateThread(function()
    Wait(500)
    GetFrameworkObject()
end)

local function DebugPrint(message)
    if Config.Debug then
        print('^3[FILTHY_TRUCKERJOB]^7 ' .. tostring(message))
    end
end

local function GetPlayer(src)
    if Config.GetFramework() == 'qbox' then
        return exports.qbx_core:GetPlayer(src)
    else
        return Framework.Functions.GetPlayer(src)
    end
end

local function ShowNotification(src, message, type, duration)
    if Config.GetFramework() == 'qbox' then
        TriggerClientEvent('QBCore:Notify', src, message, type or 'inform', duration or 5000)
    else
        TriggerClientEvent('QBCore:Notify', src, message, type or 'primary', duration or 5000)
    end
end

local function AddMoney(player, amount, reason)
    if Config.GetFramework() == 'qbox' then
        exports.ox_inventory:AddItem(player.PlayerData.source, 'money', amount)
    else
        player.Functions.AddMoney('cash', amount, reason or 'trucking-job')
    end
end

local function GetPoliceCount()
    if Config.GetFramework() == 'qbox' then
        return exports.qbx_core:GetDutyCountType('leo') or 0
    else
        local count = 0
        local players = Framework.Functions.GetPlayers()
        for _, playerId in pairs(players) do
            local player = Framework.Functions.GetPlayer(playerId)
            if player and player.PlayerData.job.type == 'leo' and player.PlayerData.job.onduty then
                count = count + 1
            end
        end
        return count
    end
end

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    
    for jobId, job in pairs(ActiveJobs) do
        if job.player then
            TriggerClientEvent('filthy_truckerjob:client:jobFailed', job.player, 'Server restart - mission cancelled')
        end
    end
    
    DebugPrint('Resource stopped, cleaned up ' .. #ActiveJobs .. ' active jobs')
end)

local function IsPlayerOnCooldown(src)
    local identifier = GetPlayerIdentifiers(src)[1]
    if not identifier then return false end
    
    if JobCooldowns[identifier] then
        local timeLeft = JobCooldowns[identifier] - os.time()
        if timeLeft > 0 then
            ShowNotification(src, 'You must wait ' .. math.ceil(timeLeft / 60) .. ' more minutes before starting another job', 'error')
            return true
        else
            JobCooldowns[identifier] = nil
        end
    end
    
    return false
end

local function SetPlayerCooldown(src)
    local identifier = GetPlayerIdentifiers(src)[1]
    if identifier then
        JobCooldowns[identifier] = os.time() + (Config.JobCooldown * 60)
        DebugPrint('Set cooldown for player: ' .. identifier .. ' (' .. Config.JobCooldown .. ' minutes)')
    end
end

local function GetRandomLocation(locationType)
    if locationType == 'pickup' then
        return Config.PickupLocations[math.random(1, #Config.PickupLocations)]
    elseif locationType == 'delivery' then
        return Config.DeliveryLocations[math.random(1, #Config.DeliveryLocations)]
    end
    return nil
end

local function CountActiveJobs()
    local count = 0
    for _ in pairs(ActiveJobs) do
        count = count + 1
    end
    return count
end

function CreateLegalPickupLocation(route)
   
    local boxSpawns = {}
    local pickup = route.pickup
    
    local playerOffset = math.random(-20, 20) 
    local angleOffset = math.random(0, 360) 
    
    for i = 1, route.boxCount do
        local angle = (i - 1) * (360 / route.boxCount) + angleOffset
        local radian = math.rad(angle)
        local distance = math.random(3, 8) + math.abs(playerOffset * 0.3) 
        
        local x = pickup.x + math.cos(radian) * distance + playerOffset
        local y = pickup.y + math.sin(radian) * distance + (playerOffset * 0.5)
        local z = pickup.z
        
        table.insert(boxSpawns, vec3(x, y, z))
    end
    
    return {
        name = route.name,
        coords = vec3(pickup.x + playerOffset, pickup.y + (playerOffset * 0.5), pickup.z), 
        boxCount = route.boxCount,
        boxSpawns = boxSpawns,
        enemyCount = 0, 
        enemySpawns = {}
    }
end
lib.callback.register('filthy_truckerjob:server:getActiveJobCount', function(source)
    local count = 0
    for _ in pairs(ActiveJobs) do
        count = count + 1
    end
    return count
end)

lib.callback.register('filthy_truckerjob:server:validateJobStart', function(source, jobType)
    local src = source
    local player = GetPlayer(src)
    
    if not player then
        return {success = false, reason = 'Player not found'}
    end
    
    local onCooldown = IsPlayerOnCooldown(src)
    if onCooldown then
        return {success = false, reason = 'You are still on cooldown'}
    end
    
    if CountActiveJobs() >= Config.MaxActiveJobs then
        return {success = false, reason = Config.Notifications.jobActive}
    end
    
    if jobType == 'illegal' then
        local policeCount = GetPoliceCount()
        if policeCount < Config.RequiredPolice then
            return {success = false, reason = Config.Notifications.noPolice}
        end
    end
    
    return {success = true}
end)

RegisterNetEvent('filthy_truckerjob:server:startJob', function(jobType)
    local src = source
    local player = GetPlayer(src)
    
    if not player then
        DebugPrint('Invalid player tried to start job: ' .. src)
        return
    end
    
    if not jobType or (jobType ~= 'illegal' and jobType ~= 'legal') then
        ShowNotification(src, 'Invalid job type selected', 'error')
        return
    end
    
    if IsPlayerOnCooldown(src) then
        return
    end
    
    if CountActiveJobs() >= Config.MaxActiveJobs then
        ShowNotification(src, Config.Notifications.jobActive, 'error')
        DebugPrint('Max active jobs reached, rejected: ' .. src)
        return
    end
    
    if jobType == 'illegal' then
        local policeCount = GetPoliceCount()
        if policeCount < Config.RequiredPolice then
            ShowNotification(src, Config.Notifications.noPolice, 'error')
            DebugPrint('Not enough police online: ' .. policeCount .. '/' .. Config.RequiredPolice)
            return
        end
    end
    
    local jobId = nextJobId
    nextJobId = nextJobId + 1
    
    local jobData = {
        id = jobId,
        player = src,
        playerName = player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname,
        startTime = os.time(),
        stage = 'started',
        type = jobType
    }
    
    if jobType == 'illegal' then
        
        local pickupLocation = GetRandomLocation('pickup')
        local deliveryLocation = GetRandomLocation('delivery')
        
        if not pickupLocation or not deliveryLocation then
            ShowNotification(src, 'Unable to generate job locations, try again', 'error')
            DebugPrint('Failed to generate locations for illegal job')
            return
        end
        
        jobData.pickupLocation = pickupLocation
        jobData.deliveryLocation = deliveryLocation
        jobData.payment = math.random(Config.Payment.min, Config.Payment.max)
        
    elseif jobType == 'legal' then
        
        local routes = {}
        local routeCount = Config.LegalJobSettings.routesPerJob
        local usedRoutes = {}
        
        for i = 1, routeCount do
            local availableRoutes = {}
            for j, route in ipairs(Config.LegalDeliveryRoutes) do
                if not usedRoutes[j] then
                    table.insert(availableRoutes, {index = j, route = route})
                end
            end
            
            if #availableRoutes > 0 then
                local selected = availableRoutes[math.random(1, #availableRoutes)]
                usedRoutes[selected.index] = true
                
                routes[i] = {
                    name = selected.route.name,
                    pickup = selected.route.pickup,
                    delivery = selected.route.delivery,
                    boxCount = Config.LegalJobSettings.boxesPerRoute,
                    payment = selected.route.payment,
                    completed = false
                }
            end
        end
        
        jobData.routes = routes
        jobData.currentRoute = 1
        jobData.routesCompleted = 0
        jobData.totalPayment = Config.LegalJobSettings.basePayment + (routeCount * Config.LegalJobSettings.routePayment)
        jobData.pickupLocation = CreateLegalPickupLocation(routes[1])
    end
    
    ActiveJobs[jobId] = jobData
    
    TriggerClientEvent('filthy_truckerjob:client:jobStarted', src, jobData)
    
    DebugPrint('Job started for player: ' .. src .. ' | ID: ' .. jobId .. ' | Type: ' .. jobType)
    if jobType == 'illegal' then
        DebugPrint('Pickup: ' .. jobData.pickupLocation.name .. ' | Payment: $' .. jobData.payment)
    else
        DebugPrint('Legal job with ' .. #jobData.routes .. ' routes | Total Payment: $' .. jobData.totalPayment)
    end
    
    SetTimeout(45 * 60 * 1000, function() 
        if ActiveJobs[jobId] then
            TriggerClientEvent('filthy_truckerjob:client:jobFailed', src, 'Job expired due to time limit')
            ActiveJobs[jobId] = nil
            DebugPrint('Job ' .. jobId .. ' expired due to timeout')
        end
    end)
end)

RegisterNetEvent('filthy_truckerjob:server:completeJob', function(jobId)
    local src = source
    local job = ActiveJobs[jobId]
    
    if not job then
        ShowNotification(src, 'Invalid job completion attempt', 'error')
        DebugPrint('Invalid job completion: ' .. jobId .. ' by player: ' .. src)
        return
    end
    
    if job.player ~= src then
        ShowNotification(src, 'You are not authorized to complete this job', 'error')
        DebugPrint('Unauthorized job completion attempt: ' .. src .. ' for job: ' .. jobId)
        return
    end
    
    local player = GetPlayer(src)
    if not player then
        DebugPrint('Player not found for job completion: ' .. src)
        return
    end
    
    local payment = 0
    local jobType = job.type or 'illegal'
    
    if jobType == 'illegal' then
        payment = job.payment
    else
        
        payment = job.totalPayment
    end
    
    AddMoney(player, payment, 'trucking-job-completion')
    
    SetPlayerCooldown(src)
    
    ActiveJobs[jobId] = nil
    
    TriggerClientEvent('filthy_truckerjob:client:jobCompleted', src, payment, jobType)
    
    DebugPrint('Job completed: ' .. jobId .. ' | Player: ' .. src .. ' | Type: ' .. jobType .. ' | Payment:  .. payment')
    
    DebugPrint('^2[FILTHY_TRUCKERJOB]^7 ' .. string.upper(jobType) .. ' job completed by ' .. job.playerName .. ' | Payment:  .. payment')
end)

RegisterNetEvent('filthy_truckerjob:server:failJob', function(jobId, reason)
    local src = source
    local job = ActiveJobs[jobId]
    
    if job and job.player == src then
        ActiveJobs[jobId] = nil
        TriggerClientEvent('filthy_truckerjob:client:jobFailed', src, reason)
        DebugPrint('Job failed: ' .. jobId .. ' | Reason: ' .. (reason or 'Unknown'))
    end
end)

RegisterNetEvent('filthy_truckerjob:server:cancelJob', function(jobId)
    local src = source
    local job = ActiveJobs[jobId]
    
    if not job then
        ShowNotification(src, 'No active job to cancel', 'error')
        return
    end
    
    if job.player ~= src then
        ShowNotification(src, 'You are not authorized to cancel this job', 'error')
        return
    end
    
    ActiveJobs[jobId] = nil
    
    TriggerClientEvent('filthy_truckerjob:client:jobCancelled', src)
    
    DebugPrint('Job cancelled by player: ' .. src .. ' | Job ID: ' .. jobId)
    
    local player = GetPlayer(src)
    if player then
        DebugPrint('^3[FILTHY_TRUCKERJOB]^7 Job cancelled by ' .. player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname)
    end
end)

lib.callback.register('filthy_truckerjob:server:getCooldownInfo', function(source)
    local src = source
    local identifier = GetPlayerIdentifiers(src)[1]
    if not identifier then return {onCooldown = false, timeRemaining = 0} end
    
    if JobCooldowns[identifier] then
        local timeLeft = JobCooldowns[identifier] - os.time()
        if timeLeft > 0 then
            return {
                onCooldown = true,
                timeRemaining = timeLeft
            }
        else
            JobCooldowns[identifier] = nil
            return {onCooldown = false, timeRemaining = 0}
        end
    end
    
    return {onCooldown = false, timeRemaining = 0}
end)

RegisterNetEvent('filthy_truckerjob:server:alertPolice', function(coords, vehicleData)
    local src = source
    
    if not coords then
        DebugPrint('Invalid coordinates for police alert')
        return
    end
    
    DebugPrint('Police alert triggered at: ' .. tostring(coords))
    
    if Config.Dispatch == 'cd_dispatch' then
        SendCDDispatch(coords)
    elseif Config.Dispatch == 'ps-dispatch' then
        SendPSDispatch(coords, src, vehicleData)
    elseif Config.Dispatch == 'custom' then
        SendCustomDispatch(coords)
    end
end)

function SendCDDispatch(coords)
    if GetResourceState('cd_dispatch') ~= 'started' then
        DebugPrint('cd_dispatch not available, falling back to custom dispatch')
        SendCustomDispatch(coords)
        return
    end
    
    local jobTable = {}
    for _, job in pairs(Config.DispatchSettings.jobs) do
        table.insert(jobTable, job)
    end
    
    local unique_id = tostring(math.random(0000000, 9999999))
    
    TriggerEvent('cd_dispatch:AddNotification', {
        job_table = jobTable,
        coords = coords,
        title = Config.DispatchSettings.title,
        message = Config.DispatchSettings.message,
        flash = 1,
        unique_id = unique_id,
        sound = 1,
        blip = {
            sprite = Config.DispatchSettings.blip.sprite,
            scale = Config.DispatchSettings.blip.scale,
            colour = Config.DispatchSettings.blip.color,
            flashes = true,
            text = Config.DispatchSettings.title,
            time = Config.DispatchSettings.blip.time,
            radius = 0,
        }
    })
    
    DebugPrint('CD Dispatch alert sent')
end

function SendPSDispatch(coords, playerId, vehicleData)
    if GetResourceState('ps-dispatch') ~= 'started' then
        DebugPrint('ps-dispatch not available, falling back to custom dispatch')
        SendCustomDispatch(coords)
        return
    end
    
    vehicleData = vehicleData or {}
    
    local dispatchData = {
        message = Config.DispatchSettings.message,
        codeName = 'trucking_heist',
        code = '10-66',
        icon = 'fas fa-truck',
        priority = 2,
        coords = coords,
        jobs = Config.DispatchSettings.jobs,
        heading = vehicleData.heading or 0,
        vehicle = vehicleData.model or 'Unknown Vehicle',
        plate = vehicleData.plate or 'Unknown',
        color = vehicleData.color or 'Unknown'
    }
    
    TriggerEvent('ps-dispatch:server:notify', dispatchData)
    DebugPrint('PS Dispatch alert sent successfully')
end

function SendCustomDispatch(coords)

    local players = {}
    if Config.GetFramework() == 'qbox' then
        local numCops, copSrcs = exports.qbx_core:GetDutyCountType('leo')
        players = copSrcs or {}
    else
        local allPlayers = Framework.Functions.GetPlayers()
        for _, playerId in pairs(allPlayers) do
            local player = Framework.Functions.GetPlayer(playerId)
            if player and player.PlayerData.job.type == 'leo' and player.PlayerData.job.onduty then
                table.insert(players, playerId)
            end
        end
    end
    
    for _, playerId in pairs(players) do
        TriggerClientEvent('police:client:policeAlert', playerId, coords, Config.DispatchSettings.message)
        ShowNotification(playerId, Config.DispatchSettings.title .. ': ' .. Config.DispatchSettings.message, 'inform', 10000)
    end
    
    DebugPrint('Custom dispatch sent to ' .. #players .. ' officers')
end

AddEventHandler('playerDropped', function(reason)
    local src = source
    
    for jobId, job in pairs(ActiveJobs) do
        if job.player == src then
            ActiveJobs[jobId] = nil
            DebugPrint('Cleaned up job ' .. jobId .. ' for disconnected player: ' .. src)
            break
        end
    end
end)

function GetActiveJobsCount()
    return CountActiveJobs()
end

function GetJobCooldownsCount()
    local count = 0
    for _ in pairs(JobCooldowns) do
        count = count + 1
    end
    return count
end

exports('GetActiveJobsCount', GetActiveJobsCount)
exports('GetJobCooldownsCount', GetJobCooldownsCount)